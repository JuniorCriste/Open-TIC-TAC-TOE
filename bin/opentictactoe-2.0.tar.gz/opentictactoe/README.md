###### _eng_
## Open Tic Tac Toe is a free and open source game developed by Junior Criste to run on Linux systems.

###### _pt-br_
### Open Tic Tac Toe é um "jogo da velha" gratuito e de código aberto desenvolvido por Junior Criste para rodar em sistemas Linux. 
###### <a href="https://opentictactoe.informaticode.com.br/2020/04/relatorio-de-atualizacao.html"> Relatório de Versões</a>
<img src="https://2.bp.blogspot.com/-JDoSha-Ompw/XqeYnmCHgAI/AAAAAAAAG6Q/cWI2wK3JolgeGzh0YPwwFwedFJlc4STnwCLcBGAsYHQ/s1600/windows.png">

###### <a href="https://opentictactoe.informaticode.com.br/download">Downloads</a>

###### <a href="https://opentictactoe.informaticode.com.br/license">License</a>


