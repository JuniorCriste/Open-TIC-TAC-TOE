 clear && cd ~ && cd .opentictactoe-cfg/configure && if [ -e configApp.txt ];  then echo arquivo existe; else echo Arquivo nao existe; fi
