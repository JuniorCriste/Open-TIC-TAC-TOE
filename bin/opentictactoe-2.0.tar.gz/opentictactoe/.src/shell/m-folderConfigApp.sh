clear && cd ~ &&  mkdir .opentictactoe-cfg
clear && cd ~ && cd .opentictactoe-cfg &&  mkdir configure
