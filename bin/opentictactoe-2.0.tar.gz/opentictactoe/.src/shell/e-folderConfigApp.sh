clear && cd ~ &&  if [ -e .opentictactoe-cfg/configure ]; then  echo Diretorio existe; else echo Diretorio nao existe; fi
