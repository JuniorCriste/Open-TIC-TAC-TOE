clear && cd ~ && cd .opentictactoe-cfg/configure &&  echo mus1 > configApp.txt; echo MUS1 DEFINIDA; fi
clear && cd ~ && cd .opentictactoe-cfg/configure &&  echo mus2 > configApp.txt; echo MUS2 DEFINIDA; fi
clear && cd ~ && cd .opentictactoe-cfg/configure &&  echo mus3 > configApp.txt; echo MUS3 DEFINIDA; fi
clear && cd ~ && cd .opentictactoe-cfg/configure &&  echo mus4 > configApp.txt; echo MUS4 DEFINIDA; fi
clear && cd ~ && cd .opentictactoe-cfg/configure &&  echo mus0 > configApp.txt; echo MUS0 DEFINIDA; fi

